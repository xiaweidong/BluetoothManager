//
//  BluetoothManager.h
//  BluetoothManager
//
//  Created by xiaweidong on 16/2/25.
//  Copyright © 2016年 xiaweidong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "BLEmanager.h"
#import "BlePeripheral.h"
#import "Commom.h"
#import "StringConvert.h"
#import "Lock.h"
#import "Ble_lock.h"
#import "Alpha_filter.h"

@interface BluetoothManager : NSObject

@end
