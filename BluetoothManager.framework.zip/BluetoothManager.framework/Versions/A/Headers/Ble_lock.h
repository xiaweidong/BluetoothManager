#import <Foundation/Foundation.h>
#import "Lock.h"
@interface Ble_lock : NSObject

@property NSMutableArray *locks;
@property NSTimer *timer_rm_locks;
@property int scene;
@property double open_lock_rssi_min_1;
@property double open_lock_rssi_min_2;

-(id)init;

-(void)timer_rm_locks_cb;

-(void)init_timer: (double)rm_intv;

-(Lock *)get_lock: (NSString *)lock_id;

-(BOOL)is_lock_exist: (NSString *)lock_id;

-(void)add_lock: (CBPeripheral *)peripheral_val : (NSString *)lock_id : (NSString *)mac : (double)x : (double)y : (double)p0 : (double)n;

-(void)set_rssi: (NSString *)lock_id : (double)rssi;

-(void)judge_scene;

-(Lock *)get_lock_to_open;

@end
