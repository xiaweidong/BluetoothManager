//
//  BlePeripheral.h
//  BLE4.0
//
//  Created by xiaweidong on 15/8/28.
//  Copyright (c) 2015年 云凯科技. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
@interface BlePeripheral : NSObject
@property(nonatomic,copy)CBPeripheral *m_peripheral;
@property(nonatomic,copy) NSString *m_peripheralIdentifier;
@property(nonatomic,copy) NSString *m_peripheralLocaName;
@property(nonatomic,copy) NSString *m_peripheralName;
@property(nonatomic,copy) NSString *m_peripheralUUID;
@property(nonatomic,copy) NSNumber *m_peripheralRSSI;
@property(nonatomic,assign)NSInteger  m_peripheralServices;
@property(nonatomic,copy) NSString *m_peripheralCodeKey;

@end
