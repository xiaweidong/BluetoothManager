//
//  BLEmanager.h
//  BLE4.0
//
//  Created by xiaweidong on 15/8/28.
//  Copyright (c) 2015年 云凯科技. All rights reserved
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "Ble_lock.h"
@protocol BLEMangerDelegate <NSObject>

- (void)bleMangerDidDiscoverPeripheral:(id)m_peripheral advertisementData:(NSDictionary *)advertisementData;
- (void)bleMangerConnectedPeripheral:(BOOL)isConnect;
- (void)bleMangerDisConnectedPeripheral:(CBPeripheral *)_peripheral;
- (void)bleMangerReceiveDataPeripheralData:(NSData *)data from_Characteristic:(CBCharacteristic *)curCharacteristic;


@end

@interface BLEmanager : NSObject<CBCentralManagerDelegate,CBPeripheralDelegate>


+(BLEmanager *)shareInstance;
@property(nonatomic,copy)     NSMutableArray   *m_array_peripheral;
@property(nonatomic,strong)   CBCentralManager *m_manger;
@property(nonatomic,strong)   CBPeripheral     *m_peripheral;
@property(nonatomic,strong)   CBCharacteristic *m_writeCharacteristic;
@property(weak,nonatomic) id<BLEMangerDelegate> mange_delegate;

-(void)initCentralManger;

@end
